package edu.csuci.collisiontest;

import java.util.LinkedList;

import android.content.Context;

public class Pool {
	private static LinkedList<SmallAsteroid> asteroids = new LinkedList<SmallAsteroid>();
	private static LinkedList<Laser> lasers = new LinkedList<Laser>();

	public static SmallAsteroid getAsteroid(Context context) {
		if(asteroids.size() == 0) {
			// Add two asteroids at a time if this is empty
			asteroids.add(new SmallAsteroid(context));
			asteroids.add(new SmallAsteroid(context));
		}
		return asteroids.removeFirst();
	}
	
	public static void returnAsteroid(SmallAsteroid asteroid) {
		asteroids.add(asteroid);
	}
	
	public static Laser getLaser(Context context) {
		if(lasers.size() == 0) {
			// Add two lasers at a time if this is empty
			lasers.add(new Laser(context));
			lasers.add(new Laser(context));
		}
		return lasers.removeFirst();
	}
	
	public static void returnLaser(Laser laser) {
		lasers.add(laser);
	}
}