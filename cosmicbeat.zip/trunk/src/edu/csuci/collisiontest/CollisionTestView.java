package edu.csuci.collisiontest;

/**
 * This file is a heavily modified version of "AnimatedGameLoopView.java" from
 * COMP425 at CSUCI
 *
 */

import java.util.LinkedList;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;


public class CollisionTestView extends SurfaceView implements SurfaceHolder.Callback {
	private final int NUM_ASTEROIDS = 7;
	boolean retry;
	class TheGameLoopThread extends Thread {
		private Context context;
	    // The drawable to use as the background of the animation canvas
	    private Bitmap mBackgroundImage;
	    // Current height of the surface/canvas.
	    private int mCanvasHeight = 320;
	    // Current width of the surface/canvas.
	    private int mCanvasWidth = 320;
	    // Used to figure out elapsed time between frames
	    private long mLastTime;
	    // Value indicating the state of the game, can be either GAME_OVER, PAUSE, or RUNNING
	    private int GameState;
	    // Indicate whether the surface has been created & is ready to draw
	    private boolean mRun = false;
	    // Handle to the surface manager object we interact with
	    private final SurfaceHolder mSurfaceHolder;
		private final LinkedList<Particle> asteroids;
		private final LinkedList<SmallAsteroid> queue;
		private final LinkedList<Laser> lasers;
		private final BlackHole blackHole;
		private final SpaceShip spaceShip;
		private long now;
		private int points;
		//Variables for angle calculations
		private double rise, run;
		// Temp variables
		Particle p1, p2;
		private int size, i, j;
		private SmallAsteroid temp1, temp2;
		private Laser laser;
		
		//Game Notifications
		Toast GameOver;
		Toast ExtraLife;
		
		//Sounds effect object
		private SoundEffects soundFX;
	
	    public TheGameLoopThread(SurfaceHolder surfaceHolder, Context context, Handler handler) {
	    	this.context = context;
	        // get handles to some important objects
	        mSurfaceHolder = surfaceHolder;
	        Resources res = context.getResources();
	        mBackgroundImage = BitmapFactory.decodeResource(res, R.drawable.background);
	        //Initialize SoundFX object
	        soundFX = new SoundEffects(context);
			// load the Asteroids 
	        asteroids = new LinkedList<Particle>();
	        queue = new LinkedList<SmallAsteroid>();
	        lasers = new LinkedList<Laser>();
	        blackHole = new BlackHole(context);
	        spaceShip = new SpaceShip(context, mCanvasWidth, mCanvasHeight);
	        //Pop-up messages for game events
	        GameOver = Toast.makeText(context, Constants.GAME_OVER_MESSAGE, Toast.LENGTH_LONG);
	        ExtraLife = Toast.makeText(context, Constants.EXTRA_LIFE_MESSAGE, Toast.LENGTH_LONG);
	        for(i = 0; i < NUM_ASTEROIDS; i++) asteroids.add(new Asteroid(context));
	        points = 0;
	    }
	
	    public void doStart() {
	        synchronized (mSurfaceHolder) {
	        	resetParticles();
	        	// set up timers
	            mLastTime = System.currentTimeMillis() + 100;
	        }
	    }
	
	    private void resetParticles() {
	    	size = asteroids.size();
	    	for(i = 0; i < size; i++) {
	    		if(asteroids.get(i) instanceof SmallAsteroid)
	    			Pool.returnAsteroid((SmallAsteroid)asteroids.remove(i));
	    		else
	    			asteroids.get(i).reset(mCanvasWidth, mCanvasHeight);
	    	}
		}

		@Override
	    public void run() {
			// Initialize
	    	doStart();
	    	// Start game loop
	        while (mRun) {
	            Canvas c = null;
	            try {
	                c = mSurfaceHolder.lockCanvas(null);
	                synchronized (mSurfaceHolder) {
	                    updatePhysics();
	                    doDraw(c);
	                }
	            } finally {
	                // do this in a finally so that if an exception is thrown
	                // during the above, we don't leave the Surface in an
	                // inconsistent state
	                if (c != null) {
	                    mSurfaceHolder.unlockCanvasAndPost(c);
	                }
	            }
	        }
	    }
	
	    /**
	     * Used to signal the thread whether it should be running or not.
	     * Passing true allows the thread to run; passing false will shut it
	     * down if it's already running. Calling start() after this was most
	     * recently called with false will result in an immediate shutdown.
	     * 
	     * @param b true to run, false to shut down
	     */
	    public void setRunning(boolean b) {
	        mRun = b;
	    }
		
	    /* Callback invoked when the surface dimensions change. */
	    public void setSurfaceSize(int width, int height) {
	        // synchronized to make sure these all change atomically
	        synchronized (mSurfaceHolder) {
	            mCanvasWidth = width;
	            mCanvasHeight = height;
	            // don't forget to resize the background image
	            mBackgroundImage = Bitmap.createScaledBitmap(mBackgroundImage, width, height, true);
	            // Move the position of the spaceship to the middle.
	            spaceShip.moveTo(width / 2, height / 2);
	            // Move the position of the blackhole
	            blackHole.moveTo(width / 4, height * (3 / 4.0));
	        }
	    }
	
	    /**
	     * Draws the spaceship, score, and background to the provided
	     * Canvas.
	     */
	    private void doDraw(Canvas canvas) {
	        // Draw the background image. Operations on the Canvas accumulate
	        // so this is like clearing the screen.
	        canvas.drawBitmap(mBackgroundImage, 0, 0, null);
	        // Draw the sprite (animation is handled within the AnimatedSprite class)
	        spaceShip.draw(canvas);
	        blackHole.draw(canvas);
	        for(i = 0; i < asteroids.size(); i++) asteroids.get(i).draw(canvas);
	        //Only fire laser if SpaceShip is ALIVE
	        if(spaceShip.state == Constants.ALIVE)
	        	for(i = 0; i < lasers.size(); i++) lasers.get(i).draw(canvas);
	        canvas.drawText("Score: " + points, 5, 30, Constants.SCORE_PAINT);
	        canvas.drawText("Lives: " + spaceShip.getNumLives(), 160, 30, Constants.SCORE_PAINT);
	        mLastTime = now;
	    }
	
	    /**
	     * Figures the game state (x, y, bounce, ...) based on the passage of
	     * realtime. Does not invalidate(). Called as part of the game loop).
	     */
	    private void updatePhysics() {
	        now = System.currentTimeMillis();
	        if (mLastTime > now) return;
	        spaceShip.update(now);
	        blackHole.update(now);
	        // Update and see if any lasers disappear off of the screen
	        for(i = 0; i < lasers.size(); i++) {
	        	laser = lasers.get(i);
	        	laser.update(now);
	        	if(laser.disappearsFromEdge(mCanvasWidth, mCanvasHeight))
	        		Pool.returnLaser(lasers.remove(i));
	        }
	        
	        // Determine if there are any collisions
	        // http://www.kirupa.com/developer/actionscript/multiple_collision2.htm
	        size = asteroids.size();
	        for(i = 0; i < size; i++) {
	        	p1 = asteroids.get(i);
	        	
	        	if(p1 instanceof SmallAsteroid)
	        		((SmallAsteroid)p1).update(now, blackHole);
	        	else
	        		p1.update(now);
	        	if(p1.disappearsFromEdge(mCanvasWidth, mCanvasHeight))
		    		p1.state = Constants.DEAD;
	        	
	        	for(j = 0; j < lasers.size(); j++) {
	        		laser = lasers.get(j);
	        		if(p1.collidesWith(laser)){
	        			laserCollision(laser, p1);
	        			soundFX.PlayRandomBeat();
	        		}
	        	}
	        	
	        	if(p1.collidesWith(blackHole)) blackHoleCollision(p1);
	        	if(p1.collidesWith(spaceShip)) {
	        		spaceShip.explode();
	        		if(spaceShip.getNumLives() <= 0) {GameOver.show();setRunning(false);}
	        		//NOTE:Only play explosion sound effect once, can be removed once
	        		//the empty space issue is resolved.
	        		if(spaceShip.state == Constants.EXPLODE) soundFX.playExplode();
	        	}
	        	for(j = i + 1; j < size; j++) {
	        		p2 = asteroids.get(j);
	        		if(p1.collidesWith(p2)){
	        			p1.resolveCollision(p2);
	        		}
	        	}
	        }
	        
	        // Reset any dead particles
	        for(i = 0; i < asteroids.size(); i++) {
	        	p1 = asteroids.get(i);
	        	if(p1.state == Constants.DEAD) {
	        		if(p1 instanceof SmallAsteroid) 
	        			Pool.returnAsteroid((SmallAsteroid)asteroids.remove(i));
	        		else
	        			p1.reset(mCanvasWidth, mCanvasHeight);
	        	}
	        }
	        // Reset any dead lasers
	        for(i = 0; i < lasers.size(); i++)
	        	if(lasers.get(i).state == Constants.DEAD)
	        		Pool.returnLaser(lasers.remove(i));
	        // Add any particles into the main array from the queue
	        asteroids.addAll(queue);
	        queue.clear();
	    }
	    
	    public void onTouchEvent(MotionEvent event) {
			//Handle laser rotation calculation here.
			if (event.getAction() == MotionEvent.ACTION_DOWN){
				if(spaceShip.state == Constants.DEAD || spaceShip.state == Constants.EXPLODE) return;
				//Reset laser if its not already at center of screen
				laser = Pool.getLaser(context);
				laser.reset(mCanvasWidth, mCanvasHeight);
				
				//Calculate angle between the line made by these two points
				//and the horizontal axis
				run = event.getX() - spaceShip.pos.x;
				rise = spaceShip.pos.y - event.getY(); 
				spaceShip.angle = Math.atan2(rise, run) * Constants.RAD_TO_DEG;
				laser.angle = Math.atan2(rise, run) * Constants.RAD_TO_DEG;
				if(spaceShip.angle < 0) { 
					spaceShip.angle += 360;
					laser.angle += 360;
				}
				spaceShip.angle -= 90;
				laser.angle -= 90;
				
				//TEST: Set velocity to coordinates of tapped point on screen
		        laser.setVelocity(run, rise);
		        lasers.add(laser);
		        soundFX.playShoot();
			}
		}
	   
	    // Returns true if we need to reset the laser
	    public void laserCollision(Laser laser, Particle asteroid) {
			if(asteroid instanceof Asteroid) {
				temp1 = Pool.getAsteroid(context);
				temp2 = Pool.getAsteroid(context);
				((Asteroid)asteroid).explode(laser, temp1, temp2);
				queue.add(temp1);
				queue.add(temp2);
				laser.state = Constants.DEAD;
			} else if(asteroid instanceof SmallAsteroid) {
				asteroid.state = Constants.DEAD;
			}
		}
	    
	    public void blackHoleCollision(Particle asteroid) {
	    	if (asteroid instanceof SmallAsteroid) {
	    		asteroid.state = Constants.DEAD;
	    		points++;
	    		//Add a life for every 25 points scored
	    		if(points % 25 == 0) { spaceShip.incrementLives(); ExtraLife.show(); }
	    		//Add an asteroid to increase difficulty
	    		if(points % Constants.NEW_ASTEROID == 0)
	    			asteroids.add(new Asteroid(context));
	    	}
	    }
	    
	    //Displays 
	    public void setState(int state){
	    	GameState = state;
	    }
	}

	private TheGameLoopThread thread;

	public CollisionTestView(Context context, AttributeSet attrs) {
		super(context, attrs);

        // register our interest in hearing about changes to our surface
        SurfaceHolder holder = getHolder();
        holder.addCallback(this);

        // create thread only; it's started in surfaceCreated()
        thread = new TheGameLoopThread(holder, context, new Handler() {
            @Override
            public void handleMessage(Message m) {
            	// process any messages
            }
        });

        setFocusable(true); // make sure we get key events
	}

	/* Callback invoked when the surface dimensions change. */
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        thread.setSurfaceSize(width, height);
    }

    /*
     * Callback invoked when the Surface has been created and is ready to be
     * used.
     */
    public void surfaceCreated(SurfaceHolder holder) {
        // start the thread here so that we don't busy-wait in run()
        // waiting for the surface to be created
        thread.setRunning(true);
        thread.start();
    }

    /*
     * Callback invoked when the Surface has been destroyed and must no longer
     * be touched. WARNING: after this method returns, the Surface/Canvas must
     * never be touched again!
     */
    public void surfaceDestroyed(SurfaceHolder holder) {
        // we have to tell thread to shut down & wait for it to finish, or else
        // it might touch the Surface after we return and explode
        retry = true;
        thread.setRunning(false);
        while (retry) {
            try {
                thread.join();
                retry = false;
            } catch (InterruptedException e) {
            }
        }
    }
    
    @Override
	public boolean onTouchEvent(MotionEvent event) {
		// Pass the touch event on to our thread
		thread.onTouchEvent(event);
		return true;
	}
}