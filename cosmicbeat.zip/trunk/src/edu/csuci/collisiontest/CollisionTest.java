package edu.csuci.collisiontest;

import android.app.Activity;
import android.os.Bundle;

public class CollisionTest extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        //Start BG_Music
        Music.play(this, R.raw.beat);
    }
    
    @Override
	protected void onPause() {
		Music.stop(this);
		super.onPause();
	}
}